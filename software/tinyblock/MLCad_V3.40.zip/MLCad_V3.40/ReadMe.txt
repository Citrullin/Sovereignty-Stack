This is the ReadMe.txt for MLCad V2.10 or higher

This file contains information for first time installation update and deinstallation.

1) First time installation:

1a)
Follow the instructions at http://www.ldraw.org/News-article-sid-90.html
to install the LDraw base package.

1b) Download the latest MLCad release from http://www.lm-software.com/mlcad/

Now deside where are you going to install the software?

Decrompress the MLCad package. It's name
depends on the actual version, e.g. mlcad33.zip is version 3.3.
Extract all files in the zip-archive using WinZip or 7-Zip in a directory of your
choice. Make sure WinZip/7-Zip restores the directory structure stored in the archive

Now run the program 'MLCad.exe' (e.g. double click on it).

A dialog will be shown asking you for a Lego Base Path, this is the
directory to which you installed the Ledit.exe and complete.exe in our
example C:\LDRAW. MLcad will not continue until the right path
has been entered.
If the right path has been entered MLCad will start up and show it's
start screen.

Now select the menu point: 'File/Scan Parts' from the MLCad menu.
It will tell you that it found new parts and ask if you allow to save
a new parts.lst file. Answere this dialog by pressing the YES button.

=== COMPLETE ===


2) Upgrading MLCad

Just install MLCad into the same directory as the first time.

=== COMPLETE ===


3) Removing MLCad

Delete the directory which contains MLCad and all it's sub-
directories. Optionally you can also delete the directories
which contain the base packages if you don't need them anymore.

Start the RegEdit program from the Start-Menu / RUN.

Now find the entry HKEY_CURRENT_USER there you find a sub-key
called SOFTWARE under this a sub-key called LACHMANN remove
the entry MLCad and all it's sub-entries.

=== COMPLETE ===
